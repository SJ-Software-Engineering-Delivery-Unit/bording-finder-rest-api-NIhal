const ROLE = Object.freeze({
  Admin: "admin",
  Client: "app-client",
  Accommodater: "accommodater",
  Moderator: "moderator",
});

module.exports = ROLE;
